module.exports = {
    applicationId: '8h0dousVavkJVOvOfKFjUv6ZmCjyWdh7QO2ICDnU',
    javascriptKey: 'AL3FxDUVFfI56raAjUPjVNdUHLiFJq3WDtWgOptP',
    serverURL: 'https://parseapi.back4app.com'
}
